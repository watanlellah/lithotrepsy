@extends('theme::pages.layout.master')

@section('content')

	Category

@endsection